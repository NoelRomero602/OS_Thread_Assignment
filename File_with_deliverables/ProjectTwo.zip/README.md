OverView:
This is a Simulation of a patient seeing a Doctor's office

How to Run:

method 1:

Download projectTwo.jar

open terminal in a system that has  java version "1.8.0_172" cs1 or cs2 both have this version in java

1. make sure to be in the same directory as the projectTwo.jar file

2. run the following command in the terminal
java -jar projectTwo.jar

method 2:

1. make sure to be in the same directory as the Main.java, Doctor.java, Patient.java
Receptionist.java and Nurse.java

2. Run the following commands

javac *.java

java Main



Note method 2 should work with most version of java and method one would work with java
versions 1.8.0_172  and up. 
